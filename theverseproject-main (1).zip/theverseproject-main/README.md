# theverseproject
The Verse Project is a web browser powered by chromium so you can browse easier.

Discord:- https://discord.gg/meeGEkBTX3

# The Discord has been purged/nuked. Everything is gone until further notice.
